<?php

namespace App\Controller\Admin;

use App\Entity\Departement;
use Doctrine\DBAL\Query\QueryBuilder;
use Doctrine\ORM\Mapping\Builder\AssociationBuilder;
use Doctrine\ORM\EntityManagerInterface;
use EasyCorp\Bundle\EasyAdminBundle\Field\IdField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;
use EasyCorp\Bundle\EasyAdminBundle\Field\AssociationField;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;

class DepartementCrudController extends AbstractCrudController
{
    public static function getEntityFqcn(): string
    {
        return Departement::class;
    }
    
    public function configureFields(string $pageName): iterable
    {
        //$repository = $this->getDoctrine()->getRepository(\App\Entity\Region::class);
        //$products = $repository->findBy([], ['region' => 'ASC', 'name' => 'ASC']);
        return [
            AssociationField::new('region'),
            IdField::new('id')->hideOnform(),
            TextField::new('nom'),
            
           // TextEditorField::new('description'),
        ];
    }
    public function deleteEntity(EntityManagerInterface $em, $entity): void
    {
        if(!$entity instanceof Departement)
        return;
        foreach($entity->getCommunes() as $departement)
        {
            $em ->remove($departement);
        }
        parent::deleteEntity($em,$entity);
    }
    
    
}
