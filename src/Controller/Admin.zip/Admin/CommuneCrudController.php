<?php

namespace App\Controller\Admin;

use App\Entity\Commune;
use Doctrine\ORM\Mapping\Builder\AssociationBuilder;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use EasyCorp\Bundle\EasyAdminBundle\Field\IdField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;
use EasyCorp\Bundle\EasyAdminBundle\Config\Actions;
use EasyCorp\Bundle\EasyAdminBundle\Config\Crud;
use EasyCorp\Bundle\EasyAdminBundle\Config\Action;
use EasyCorp\Bundle\EasyAdminBundle\Field\AssociationField;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;
//use Symfony\Component\BrowserKit\Response;

class CommuneCrudController extends AbstractCrudController
{
    public const ACTION_NOMMER = 'nommerMaire';
    public static function getEntityFqcn(): string
    {
        return Commune::class;
    }

    public function configureActions(Actions $action): Actions
    {
       $nommerMaire = Action::new(self::ACTION_NOMMER)
                    ->linkToCrudAction('nommerMaire')
                    ->setCssClass('btn btn-primary');
                    return $action
                          ->add(Crud::PAGE_EDIT, $nommerMaire);
    }
    
    public function configureFields(string $pageName): iterable
    {
        return [
            AssociationField::new('departement'),
            IdField::new('id')->hideOnForm(),
            TextField::new('nom'),
           
        ];
    
    }
    
    #[Route("/admin/commune/{id}", name:"admin_commune_show")]
    public function show($id): Response
    {
        return new Response('Commune id: '.$id);
    }


   /* public function nommerMaire():Response
    {
        
    }*/
}
