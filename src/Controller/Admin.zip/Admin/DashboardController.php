<?php

namespace App\Controller\Admin;

use App\Entity\Commune;
use App\Entity\Departement;
use App\Entity\Personne;
use App\Entity\Region;
use EasyCorp\Bundle\EasyAdminBundle\Config\Dashboard;
use EasyCorp\Bundle\EasyAdminBundle\Config\Actions;
use EasyCorp\Bundle\EasyAdminBundle\Config\Crud;
use EasyCorp\Bundle\EasyAdminBundle\Config\MenuItem;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractDashboardController;
use EasyCorp\Bundle\EasyAdminBundle\Router\AdminUrlGenerator;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class DashboardController extends AbstractDashboardController
{
    public function __construct(private AdminUrlGenerator $adminUrlGenerator )
    {
        
    }
    #[Route('/admin', name: 'admin')]
    public function index(): Response       
    {
        $url = $this->adminUrlGenerator
            ->setController(RegionCrudController::class)
            ->generateUrl();
        //return parent::index();
        //return $this->redirect($url);
        return $this->redirect($url );
       
    }
    


    public function configureDashboard(): Dashboard
    {
        return Dashboard::new()
            ->setTitle('Sama-Domicile');
    }

    public function configureMenuItems(): iterable
    {
        yield MenuItem::linkToDashboard('Dashboard', 'fa fa-home');

        //Pour les regions
        yield MenuItem::section('Region');
        yield MenuItem::subMenu('Actions','fas fa-bars')->setSubItems([
               MenuItem::linkToCrud('Creer une region','fas fa-plus',Region::class)->setAction(Crud::PAGE_NEW),
               MenuItem::linkToCrud('Visualier les regions','fas fa-eye',Region::class)
        ]);
        //Pour les departements
        yield MenuItem::section('Departement');
        yield MenuItem::subMenu('Actions','fas fa-bars')->setSubItems([
               MenuItem::linkToCrud('Creer un departement','fas fa-plus',Departement::class)->setAction(Crud::PAGE_NEW),
               
               MenuItem::linkToCrud('Visualier les departements','fas fa-eye',Departement::class)
        ]);

        //Pour les communes
        yield MenuItem::section('Commune');
        yield MenuItem::subMenu('Actions','fas fa-bars')->setSubItems([
                MenuItem::linkToCrud('Creer une commune','fas fa-plus',Commune::class)->setAction(Crud::PAGE_NEW),
                MenuItem::linkToCrud('Visualier les communes','fas fa-eye',Commune::class),
                MenuItem::linkToCrud('Choisir un maire','fas fa-eye',Personne::class),
        ]);

       





       
        // yield MenuItem::linkToCrud('The Label', 'fas fa-list', EntityClass::class);
    }
}
