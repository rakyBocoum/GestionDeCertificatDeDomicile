<?php

namespace App\Controller\Admin;

use App\Entity\Region;
use Doctrine\ORM\EntityManagerInterface;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;
use EasyCorp\Bundle\EasyAdminBundle\Field\IdField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;


class RegionCrudController extends AbstractCrudController
{
    public static function getEntityFqcn(): string
    {
        return Region::class;
    }

    
    public function configureFields(string $pageName): iterable
    {
        return 
        [
            IdField::new('id')->hideOnForm(),
            TextField::new('nom'),
            
        ];
    }
    public function deleteEntity(EntityManagerInterface $em, $entity): void
    {
        if(!$entity instanceof Region)
        return;
        foreach($entity->getDepartements() as $departement)
        {
            $em ->remove($departement);
        }
        parent::deleteEntity($em,$entity);
    }
    
}
